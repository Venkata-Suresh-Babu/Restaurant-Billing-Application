import sqlite3
import csv
import os
from datetime import datetime

database_name = "restaurant.db"
save_file_path = r"C:\Users\venka\OneDrive\Desktop\Restaurant-Billing-Application"

def fetch_daily_order_details():
    try:
        conn = sqlite3.connect(database_name)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                Orders.token_number,
                Menu.Dish_Name,
                order_items.quantity,
                Orders.total_amount,
                Orders.order_date
            FROM Orders
            JOIN order_items ON Orders.order_id = order_items.order_id
            JOIN Menu ON order_items.item_id = Menu.item_id
            ORDER BY Orders.order_date;
        """)
        orders = cursor.fetchall()
        conn.close()
        return orders

    except sqlite3.Error as e:
        print(f"Error Fetching Order details: {e}")
        return None

def display_orders(orders):
    if not orders:
        print("No orders found to save.")
        return

    year_data = {}
    for order in orders:
        token_number, dish_name, quantity, total_amount, order_date = order
        try:
            year = datetime.strptime(order_date, "%Y-%m-%dT%H:%M:%S.%f").year
        except ValueError:
            year = datetime.strptime(order_date, "%Y-%m-%d").year
        if year not in year_data:
            year_data[year] = []
        year_data[year].append([token_number, dish_name, quantity, total_amount, order_date])

    for year, data in year_data.items():
        print(f"\n Orders for the year {year}")
        print("Token Number | Dish Name | Quantity | Total Amount | Order Date")
        for row in data:
            print(f"{row[0]} | {row[1]} | {row[2]} | {row[3]} | {row[4]}")

if __name__ == "__main__":
    orders = fetch_daily_order_details()
    if orders:
        display_orders(orders)
    else:
        print("No orders found to save.")